// /frontend/src/app/signals/page.tsx
'use client'
import { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'

/* ─── Types ──────────────────────────────────────────────────────────────── */
type SignalType = 'STRONG BUY' | 'BUY' | 'NEUTRAL' | 'AVOID'
type FilterTab = 'All' | 'Opportunities' | 'Watch' | 'Avoid'

/* ─── Display label map ───────────────────────────────────────────────────── */
function signalDisplayLabel(signal: SignalType): string {
  if (signal === 'STRONG BUY') return 'Strong Opportunity'
  if (signal === 'BUY') return 'Good Opportunity'
  if (signal === 'AVOID') return 'Not Recommended'
  return 'Wait and Watch'
}

/* ─── Types ──────────────────────────────────────────────────────────────── */
interface Signal {
  symbol: string
  name: string
  exchange?: string
  signal: SignalType
  score: number
  reasons: string[]
  trust_score?: number
  horizon?: string
  sector?: string
  price?: number
}

interface SignalOutcome {
  total: number
  hit_target: number
  days: number
  win_rate: number
}

/* ─── Helpers ────────────────────────────────────────────────────────────── */
const API = 'http://localhost:8000'

function signalColor(signal: SignalType): string {
  if (signal === 'STRONG BUY' || signal === 'BUY') return 'var(--green)'
  if (signal === 'AVOID') return 'var(--red)'
  return 'var(--amber)'
}

function signalBadgeClass(signal: SignalType): string {
  if (signal === 'STRONG BUY' || signal === 'BUY') return 'badge badge-green'
  if (signal === 'AVOID') return 'badge badge-red'
  return 'badge badge-amber'
}

function scoreLabel(score: number): string {
  if (score >= 75) return 'Strong'
  if (score >= 50) return 'Good'
  if (score >= 35) return 'Mixed'
  return 'Weak'
}

function scoreColor(score: number): string {
  if (score >= 75) return 'var(--green)'
  if (score >= 50) return 'var(--amber)'
  return 'var(--red)'
}

/* ─── ScoreBar ────────────────────────────────────────────────────────────── */
function ScoreBar({ score, compact }: { score: number; compact?: boolean }) {
  const pct = Math.min(100, Math.max(0, score))
  const color = scoreColor(pct)
  const label = scoreLabel(pct)
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        flex: 1, height: compact ? 2 : 3,
        background: 'var(--surface-3)', borderRadius: 2, overflow: 'hidden',
      }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 2 }} />
      </div>
      <span className="num" style={{ fontSize: 11, color: 'var(--text-muted)', minWidth: 24 }}>{pct}</span>
      <span style={{ fontSize: 11, color, fontWeight: 600, minWidth: 36 }}>{label}</span>
    </div>
  )
}

/* ─── ScoreLegend ─────────────────────────────────────────────────────────── */
function ScoreLegend() {
  const [open, setOpen] = useState(false)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          background: 'none',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius)',
          color: 'var(--accent)',
          fontSize: 12,
          padding: '6px 12px',
          cursor: 'pointer',
          width: 'fit-content',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}
      >
        <span>How scores work</span>
        <span style={{ fontSize: 10 }}>{open ? '▲' : '▼'}</span>
      </button>

      {open && (
        <div style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          borderRadius: 'var(--radius-lg)',
          padding: '16px 18px',
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
        }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>
            Opportunity Rating Explained
          </div>
          {[
            { range: '75–100', label: 'Strong Opportunity', desc: 'Multiple positive signals aligning', color: 'var(--green)' },
            { range: '50–74', label: 'Good Opportunity', desc: 'More positives than negatives', color: 'var(--green)' },
            { range: '35–49', label: 'Wait and Watch', desc: 'Mixed signals, no clear direction', color: 'var(--amber)' },
            { range: '0–34', label: 'Not Recommended', desc: 'More risks than opportunities', color: 'var(--red)' },
          ].map(item => (
            <div key={item.range} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <span className="num" style={{
                fontSize: 11, fontWeight: 700, color: item.color,
                minWidth: 44, paddingTop: 1,
              }}>
                {item.range}
              </span>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)' }}>{item.label}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 1 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── TradePlan ───────────────────────────────────────────────────────────── */
function TradePlan({ signal }: { signal: Signal }) {
  if (!signal.price) return null
  const price = signal.price
  const stopLoss = Math.round(price * 0.94)
  const target = Math.round(price * 1.10)

  return (
    <div style={{
      background: 'var(--surface-2)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius)',
      padding: '14px 16px',
      marginTop: 12,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
    }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>
        Trade Plan
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 2 }}>Buy around</div>
          <div className="num" style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>₹{price.toLocaleString('en-IN')}</div>
        </div>
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 2 }}>Target</div>
          <div className="num" style={{ fontSize: 14, fontWeight: 700, color: 'var(--green)' }}>₹{target.toLocaleString('en-IN')}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>Expected gain of 10%</div>
        </div>
        <div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 2 }}>Stop loss</div>
          <div className="num" style={{ fontSize: 14, fontWeight: 700, color: 'var(--red)' }}>₹{stopLoss.toLocaleString('en-IN')}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 1 }}>Exit if it falls 6% to limit your loss</div>
        </div>
        {signal.horizon && (
          <div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 2 }}>Hold for</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{signal.horizon}</div>
          </div>
        )}
      </div>
      <div style={{
        marginTop: 4,
        padding: '8px 10px',
        background: 'var(--surface)',
        borderRadius: 6,
        fontSize: 11,
        color: 'var(--text-secondary)',
        lineHeight: 1.5,
        borderLeft: '3px solid var(--amber)',
      }}>
        Risk management: Never risk more than 1–2% of your total money on a single trade.
      </div>
    </div>
  )
}

/* ─── Signal Card ─────────────────────────────────────────────────────────── */
function SignalCard({ signal }: { signal: Signal }) {
  const [expanded, setExpanded] = useState(false)
  const borderColor = signalColor(signal.signal)
  const trust = signal.trust_score ?? Math.round(60 + signal.score * 0.3)
  const isBuy = signal.signal === 'STRONG BUY' || signal.signal === 'BUY'

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderLeft: `3px solid ${borderColor}`,
      borderRadius: 'var(--radius-lg)',
      padding: '16px 18px',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, marginBottom: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--text-primary)' }}>{signal.name}</span>
            <span className="num" style={{
              fontSize: 11, color: 'var(--text-muted)',
              background: 'var(--surface-2)', padding: '1px 6px', borderRadius: 4,
            }}>
              {signal.symbol}{signal.exchange ? ` · ${signal.exchange}` : ''}
            </span>
            {signal.sector && (
              <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{signal.sector}</span>
            )}
          </div>
          <div style={{ marginTop: 8 }}>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>
              Opportunity Rating
            </div>
            <ScoreBar score={signal.score} />
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
          <span className={signalBadgeClass(signal.signal)}>{signalDisplayLabel(signal.signal)}</span>
          {signal.horizon && (
            <span style={{ fontSize: 10, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{signal.horizon}</span>
          )}
        </div>
      </div>

      {/* Reasons */}
      {signal.reasons.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 12 }}>
          {signal.reasons.slice(0, 3).map((r, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <span style={{ color: borderColor, marginTop: 3, flexShrink: 0, fontSize: 9 }}>◆</span>
              <span style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{r}</span>
            </div>
          ))}
        </div>
      )}

      {/* Trade Plan (expanded, buy signals only) */}
      {isBuy && expanded && <TradePlan signal={signal} />}

      {/* Footer */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 10, borderTop: '1px solid var(--border)', marginTop: isBuy && expanded ? 12 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Trust </span>
            <span className="num" style={{ fontSize: 12, fontWeight: 600, color: trust >= 70 ? 'var(--green)' : 'var(--amber)' }}>{trust}%</span>
          </div>
          {isBuy && (
            <button
              onClick={() => setExpanded(v => !v)}
              style={{
                background: 'none',
                border: '1px solid var(--border)',
                borderRadius: 6,
                color: 'var(--text-secondary)',
                fontSize: 11,
                padding: '3px 10px',
                cursor: 'pointer',
              }}
            >
              {expanded ? 'Hide plan' : 'Show trade plan'}
            </button>
          )}
        </div>
        <Link href={`/analytics?symbol=${signal.symbol}`} style={{ fontSize: 12, color: 'var(--accent)', textDecoration: 'none' }}>
          Deep Analysis →
        </Link>
      </div>
    </div>
  )
}

/* ─── Track Record ────────────────────────────────────────────────────────── */
function TrackRecord() {
  const [data, setData] = useState<SignalOutcome | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`${API}/api/user/signal-outcomes`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false) })
      .catch(() => { setData(null); setLoading(false) })
  }, [])

  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      padding: '20px 22px',
    }}>
      <h3 style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 16 }}>
        Signal Track Record
      </h3>

      {loading ? (
        <div className="skeleton" style={{ height: 60 }} />
      ) : data && data.total > 0 ? (
        <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Last {data.days} days</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', marginTop: 2 }}>
              {data.hit_target} / {data.total}
              <span style={{ fontSize: 13, fontWeight: 400, color: 'var(--text-muted)', marginLeft: 8 }}>signals hit target</span>
            </div>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Win rate</div>
            <div className="num" style={{ fontSize: 22, fontWeight: 700, color: data.win_rate >= 60 ? 'var(--green)' : 'var(--amber)', marginTop: 2 }}>
              {data.win_rate.toFixed(0)}%
            </div>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
            Every recommendation this system makes is logged. Here is how past signals actually performed.
          </p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Track record builds as signals age — check back in 2 weeks to see hit rate, average return, and win/loss breakdown.
          </p>
        </div>
      )}
    </div>
  )
}

/* ─── Filter Tabs ─────────────────────────────────────────────────────────── */
function FilterTabs({ active, onChange }: { active: FilterTab; onChange: (f: FilterTab) => void }) {
  const tabs: FilterTab[] = ['All', 'Opportunities', 'Watch', 'Avoid']

  return (
    <div style={{ display: 'flex', gap: 4, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: 4, width: 'fit-content' }}>
      {tabs.map(tab => (
        <button
          key={tab}
          onClick={() => onChange(tab)}
          style={{
            background: active === tab ? 'var(--surface-3)' : 'none',
            border: 'none',
            color: active === tab ? 'var(--text-primary)' : 'var(--text-muted)',
            fontWeight: active === tab ? 600 : 400,
            fontSize: 12,
            padding: '5px 12px',
            borderRadius: 6,
            cursor: 'pointer',
            transition: 'all 0.12s',
          }}
        >
          {tab}
        </button>
      ))}
    </div>
  )
}

/* ─── Mock data ───────────────────────────────────────────────────────────── */
const MOCK_SIGNALS: Signal[] = [
  {
    symbol: 'HAL',
    name: 'Hindustan Aeronautics Ltd',
    exchange: 'NSE',
    signal: 'STRONG BUY',
    score: 88,
    sector: 'Defence',
    price: 4120,
    reasons: [
      'Large institutional investors have been buying for 6 weeks in a row',
      'Government defence budget is at an all-time high, directly benefiting HAL',
      'Order book is full for the next 3 years — revenue is predictable',
    ],
    trust_score: 84,
    horizon: '2–4 weeks',
  },
  {
    symbol: 'ONGC',
    name: 'Oil & Natural Gas Corp',
    exchange: 'NSE',
    signal: 'BUY',
    score: 74,
    sector: 'Energy',
    price: 268,
    reasons: [
      'Rising global oil prices directly increase company profits',
      'Stock is trading below its historical average price, making it a value pick',
      'Government is increasing spending on domestic energy — ONGC benefits directly',
    ],
    trust_score: 71,
    horizon: '3–6 weeks',
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank',
    exchange: 'NSE',
    signal: 'NEUTRAL',
    score: 52,
    sector: 'Banking',
    price: 1680,
    reasons: [
      'Uncertainty about the next RBI interest rate decision is keeping investors cautious',
      'The bank is fundamentally strong but short-term direction is unclear',
      'Wait for the next quarterly result before taking a position',
    ],
    trust_score: 61,
    horizon: '—',
  },
  {
    symbol: 'INFY',
    name: 'Infosys Ltd',
    exchange: 'NSE',
    signal: 'AVOID',
    score: 28,
    sector: 'IT',
    price: 1520,
    reasons: [
      'Large investors have been selling for 8 weeks straight',
      'The company cut its own revenue expectations last quarter — a warning sign',
      'Global demand for IT services is slowing down, hurting new order wins',
    ],
    trust_score: 77,
    horizon: '4–8 weeks',
  },
]

/* ─── Page ────────────────────────────────────────────────────────────────── */
export default function SignalsPage() {
  const [signals, setSignals] = useState<Signal[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<FilterTab>('All')

  useEffect(() => {
    fetch(`${API}/api/alerts/signals`)
      .then(r => r.json())
      .then(d => {
        const arr = Array.isArray(d) ? d : (d.alerts ?? d.results ?? [])
        const mapped: Signal[] = arr.map((a: any) => ({
          symbol: a.symbol,
          name: a.name,
          exchange: a.exchange,
          signal: a.signal,
          score: a.score,
          reasons: a.score_breakdown ?? a.reasons ?? [],
          trust_score: a.trust_score,
          horizon: a.horizon,
          sector: a.sector,
          price: a.price,
        }))
        setSignals(mapped.length > 0 ? mapped : MOCK_SIGNALS)
        setLoading(false)
      })
      .catch(() => { setSignals(MOCK_SIGNALS); setLoading(false) })
  }, [])

  const filtered = useMemo(() => {
    if (filter === 'All') return signals
    if (filter === 'Opportunities') return signals.filter(s => s.signal === 'BUY' || s.signal === 'STRONG BUY')
    if (filter === 'Avoid') return signals.filter(s => s.signal === 'AVOID')
    return signals.filter(s => s.signal === 'NEUTRAL')
  }, [signals, filter])

  const counts = useMemo(() => ({
    buy: signals.filter(s => s.signal === 'BUY' || s.signal === 'STRONG BUY').length,
    avoid: signals.filter(s => s.signal === 'AVOID').length,
    neutral: signals.filter(s => s.signal === 'NEUTRAL').length,
  }), [signals])

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '28px 20px', display: 'flex', flexDirection: 'column', gap: 28 }}>

      {/* Header */}
      <div>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>Investment Opportunities</h1>
        <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Every opportunity analysed, explained, and tracked.</p>
      </div>

      {/* Score Legend (toggleable) */}
      <ScoreLegend />

      {/* Summary row */}
      {!loading && (
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {[
            { label: 'Opportunities', count: counts.buy, color: 'var(--green)' },
            { label: 'Not Recommended', count: counts.avoid, color: 'var(--red)' },
            { label: 'Wait and Watch', count: counts.neutral, color: 'var(--amber)' },
          ].map(item => (
            <div key={item.label} style={{
              background: 'var(--surface)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius)', padding: '10px 16px', flex: '1 1 100px',
              display: 'flex', flexDirection: 'column', gap: 2,
            }}>
              <div className="num" style={{ fontSize: 22, fontWeight: 700, color: item.color }}>{item.count}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filter */}
      <FilterTabs active={filter} onChange={setFilter} />

      {/* Signal list */}
      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[1, 2, 3, 4].map(i => <div key={i} className="skeleton" style={{ height: 140 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{
          background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 'var(--radius-lg)', padding: '32px', textAlign: 'center',
        }}>
          <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>No signals in this category right now.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(s => <SignalCard key={s.symbol} signal={s} />)}
        </div>
      )}

      {/* Divider */}
      <div style={{ height: 1, background: 'var(--border)' }} />

      {/* Track Record */}
      <TrackRecord />

    </div>
  )
}
